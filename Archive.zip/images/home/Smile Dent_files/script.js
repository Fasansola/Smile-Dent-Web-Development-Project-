let avatars = document.querySelectorAll('.hero-thumbnail')
avatars[0].style.zIndex = '3';
avatars[1].style.zIndex = '2';
avatars[2].style.zIndex = '1';
avatars[3].style.zIndex = '0';